<?php 
	$server = 'localhost';
	$namedb = 'learnphp';
	$user = 'root';
	$password = '';

	$connect = mysqli_connect($server, $user, $password, $namedb);
	mysqli_set_charset($connect,"utf8");

	if (mysqli_connect_errno())
	{
	  	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
?>