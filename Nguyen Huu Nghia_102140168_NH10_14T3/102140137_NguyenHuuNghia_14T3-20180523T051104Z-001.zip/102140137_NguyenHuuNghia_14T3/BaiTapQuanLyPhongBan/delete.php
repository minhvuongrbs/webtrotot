<?php
    require_once 'connect.php';
    $id = $_POST['id'];
    $query = "DELETE FROM nhanvien WHERE id = {$id}";
    $result = $connect->query($query);

    if ($result) {
        echo "xoa thanh cong";
    } else {
        echo "Xoa that bai";
    }
?>
