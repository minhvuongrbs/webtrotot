<?php 
    require_once 'templates/header.php';
    
    if (!isset($_SESSION['user'])) {
        header("location: login.php");
    }
?>
<div class="card mb-3">
    <div class="card-header">
        <i class="fa fa-table"></i> NHÂN VIÊN</div>
    <div class="card-body">
        <div class="table-responsive">
            <?php
                if (isset($_GET['msg'])) {
            ?>
                <p class="bg-primary" style="padding: 10px; color: #FFF;"><?php echo $_GET['msg'] ?></p>
            <?php    
                } if (isset($_GET['error'])) {
            ?>
                <p class="bg-danger" style="padding: 10px; color: #FFF;"><?php echo $_GET['error'] ?></p>
            <?php    
                }
            ?>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Mã nhân viên</th>
                        <th>Họ tên</th>
                        <th>Đại chỉ</th>
                        <th>Sửa</th>
                        <th>Xóa</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    if (isset($_GET['id'])) {
                        $pbId = $_GET['id'];
                        $query = "select * from nhanvien where pb_id = {$pbId}";
                    } else {
                        $query = "select * from nhanvien";
                    }

                    $result = $connect->query($query);
                    $row = mysqli_fetch_assoc($result);
                    $i = 0;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $manv = $row['manv'];
                        $ten = $row['ten'];
                        $diachi = $row['diachi'];
                ?>
                    <tr>
                        <td><?php echo ++ $i ?></td>
                        <td><?php echo $manv ?></td>
                        <td><?php echo $ten ?></td>
                        <td><?php echo $diachi ?></td>
                        <td>
                            <a class="btn btn-primary" href="editnhanvien.php?id=<?php echo $id ?>"><i class="fa fa-edit"></i></a>
                        </td>
                        <td>
                            <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="xoanhanvien.php?pbid=<?php echo $pbId ?>&id=<?php echo $id ?>"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                <?php 
                    }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php 
    require_once 'templates/footer.php';
?>
