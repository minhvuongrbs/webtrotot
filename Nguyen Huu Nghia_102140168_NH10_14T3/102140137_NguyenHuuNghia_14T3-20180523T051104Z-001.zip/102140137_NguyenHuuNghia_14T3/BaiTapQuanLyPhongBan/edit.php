<?php
    require_once 'templates/header.php';
    
    if (!isset($_SESSION['user'])) {
        header("location: login.php");
    }

    $id = $_GET['id'];
    $query = "select * from nhanvien where id = {$id}";
    $result = $connect->query($query);
    $row = mysqli_fetch_assoc($result);

    if (isset($_POST['submit'])) {
        $ten = $_POST['ten'];
        $pb_id = $_POST['pb_id'];
        $diachi = $_POST['diachi'];
        if ($ten == '' || $diachi == '') {
            echo "Cac truong ko the de trong!";
        } else {
            $update = "update nhanvien set ten = '{$ten}', pb_id = {$pb_id}, diachi = '{$diachi}' where id = {$id}";

            if ($connect->query($update)) {
                header("location:nhanvien.php?id={$pb_id}");
            } else {
                echo "error";
            }
        }
    }
?>
<h2 class="title">Update employee</h2>
<form method="post" action="">
    <table>
        <tr>
            <td>Ten: </td>
            <td><input type="text" name="ten" id="name" value="<?php echo $row['ten'] ?>"></td>
        </tr>
        <tr>
            <td>Phong ban: </td>
            <td>
                <select name="pb_id">
                    <?php 
                        $query2 = "select * from phongban";
                        $result2 = $connect->query($query2);
                        while ($row2 = mysqli_fetch_assoc($result2)) {
                    ?>
                        <option value="<?php echo $row2['id'] ?>"
                            <?php
                                echo $row['pb_id'] == $row2['id'] ? "selected" : "";
                            ?>
                            >
                            <?php echo $row2['id'] ?>
                        </option>
                    <?php
                        }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Dia chi: </td>
            <td><input type="text" id="text" name="diachi" value="<?php echo $row['diachi'] ?>"></td>
        </tr>
        <tr>
            <td><input type="button" name="reset" onclick="myClear()" value="Reset"></td>
            <td><input type="submit" name="submit" value="Edit"></td>
        </tr>
    </table>
    <script type="text/javascript">
        function myClear() {
            document.getElementById('text').value = "";
            document.getElementById('name').value = "";
        }
    </script>
</form>
<?php 
    require_once 'templates/footer.php';
?>