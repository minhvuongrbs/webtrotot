<?php 
	require_once 'templates/header.php';
	unset($_SESSION['user']);
	header("location:login.php");
?>