<?php
    require_once 'templates/header.php';

    if (!isset($_SESSION['user'])) {
        header("location: login.php");
    }

    if (isset($_POST['submit'])) {
        $maNv = $_POST['manv'];
        $ten = $_POST['ten'];
        $pb_id = $_POST['pb_id'];
        $diachi = $_POST['diachi'];
        if ($ten == '' || $diachi == '' || $maNv == '') {
            $valid = 'Cac truong ko the de trong!';
        } else {
            $insert = "insert into nhanvien (manv, ten, pb_id, diachi) values ('{$maNv}','{$ten}', {$pb_id}, '{$diachi}')";

            if ($connect->query($insert)) {
                header("location:nhanvien.php?msg=Thêm thành công");
            } else {
                header("location:nhanvien.php?error=Thêm that bai");
            }
        }
    }
?>
<div class="wrapper-edit">
    <div class="card-header">
        <i class="fa fa-edit"></i> Add employee</div>
    <div class="card-body">
        <div class="table-responsive">
            <?php
                if (isset($valid)) {
                    echo "<span class='error-login'>{$valid}</span>";
                }
            ?>
            <form method="post" action="">
                <table>
                    <tr>
                        <td>MaNV: </td>
                        <td><input class="form-control" type="text" name="manv" id="manv"></td>
                    </tr>
                    <tr>
                        <td>Ten: </td>
                        <td><input class="form-control" type="text" name="ten" id="name"></td>
                    </tr>
                    <tr>
                        <td>Phong ban: </td>
                        <td>
                            <select class="form-control" name="pb_id">
                                <?php
                                    $query2 = "select * from phongban";
                                    $result2 = $connect->query($query2);
                                    while ($row2 = mysqli_fetch_assoc($result2)) {
                                ?>
                                    <option value="<?php echo $row2['id'] ?>">
                                        <?php echo $row2['id'] ?>
                                    </option>
                                <?php
                                    }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Dia chi: </td>
                        <td><input class="form-control" type="text" id="text" name="diachi"></td>
                    </tr>
                    <tr>
                        <td><input class="btn btn-default" type="button" name="reset" onclick="myClear()" value="Reset"></td>
                        <td><input class="btn btn-primary" type="submit" name="submit" value="Add"></td>
                    </tr>
                </table>
                <script type="text/javascript">
                    function myClear() {
                        document.getElementById('text').value = "";
                        document.getElementById('name').value = "";
                    }
                </script>
            </form>
        </div>
    </div>
</div>
<?php
    require_once 'templates/footer.php';
?>
