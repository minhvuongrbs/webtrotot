-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th5 04, 2018 lúc 12:21 AM
-- Phiên bản máy phục vụ: 5.7.22-0ubuntu0.16.04.1
-- Phiên bản PHP: 7.1.16-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `learnphp`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhanvien`
--

CREATE TABLE `nhanvien` (
  `id` int(10) NOT NULL,
  `ten` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `pb_id` int(10) NOT NULL,
  `diachi` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nhanvien`
--

INSERT INTO `nhanvien` (`id`, `ten`, `pb_id`, `diachi`) VALUES
(1, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(2, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(3, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(4, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(8, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(9, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(11, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(12, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(13, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(14, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(15, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(16, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(17, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(18, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(19, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(20, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(21, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(22, 'Nguyễn Văn A', 1, '54 Nguyễn Lương Băng'),
(24, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(25, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(26, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(27, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(28, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(29, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(30, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(31, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(32, 'Phan Văn B', 2, '54 Nguyễn Lương Băng'),
(33, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(34, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(35, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(36, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(37, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(38, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(39, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(40, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(41, 'Trần Văn C', 3, '54 Nguyễn Lương Băng'),
(42, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(43, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(44, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(45, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(46, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(47, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(48, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(49, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(50, 'Mai Văn D', 4, '54 Nguyễn Lương Băng'),
(51, 'Mai Văn D', 4, '54 Nguyễn Lương Băng');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phongban`
--

CREATE TABLE `phongban` (
  `id` int(10) NOT NULL,
  `mota` text COLLATE utf8_unicode_ci NOT NULL,
  `thoigian` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `phongban`
--

INSERT INTO `phongban` (`id`, `mota`, `thoigian`) VALUES
(1, 'Phòng ban 1', '2018-04-04'),
(2, 'Phòng ban 2', '2018-04-04'),
(3, 'Phòng ban 3', '2018-04-04'),
(4, 'Phòng ban 4', '2018-04-04');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'thanh', '1234');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `phongban`
--
ALTER TABLE `phongban`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `nhanvien`
--
ALTER TABLE `nhanvien`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT cho bảng `phongban`
--
ALTER TABLE `phongban`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
