<?php
    require_once 'connect.php';
    $id = $_GET['id'];
    $pbId = $_GET['pbid'];
    $query = "DELETE FROM nhanvien WHERE id = {$id}";

	if ($connect->query($query)) {
        header("location:nhanvien.php?id={$pbId}&msg=Xóa thành công");
    } else {
        header("location:nhanvien.php?id={$pbId}&error=Xóa that bai");
    }
?>
