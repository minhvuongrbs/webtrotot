<?php 
    session_start();
    require_once 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login</title>
    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="bg-dark">
    <div class="container">
        <div class="card card-login mx-auto mt-5">
            <div class="card-header">Login</div>
            <div class="card-body">
                <?php
                    $error = '';

                    if (isset($_POST['login'])) {
                        $username = trim($_POST['username']);
                        $password = trim($_POST['password']);

                        $query = "select * from user where username = '{$username}' and password = '{$password}'";
                        $result = $connect->query($query);

                        $row = mysqli_fetch_assoc($result);
                        $_SESSION['user'] = $row;

                        if ($row) {
                            header("location: phongban.php");
                        } else {
                            $error = 'Invalid username and password !';
                        }
                    }
                ?>
                <form method="post">
                    <span class="error-login"><?php echo $error; ?></span>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Username</label>
                        <input class="form-control" id="exampleInputEmail1" type="text"
                            aria-describedby="emailHelp" required placeholder="Enter email"
                            name="username">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input class="form-control" required id="exampleInputPassword1"
                            type="password" placeholder="Password" name="password">
                    </div>
                    <div class="form-group">
                        <div class="form-check">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox"> Remember Password</label>
                        </div>
                    </div>
                    <input class="btn btn-primary btn-block" type="submit" name="login" value="Login">
                </form>
            </div>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>
</html>
