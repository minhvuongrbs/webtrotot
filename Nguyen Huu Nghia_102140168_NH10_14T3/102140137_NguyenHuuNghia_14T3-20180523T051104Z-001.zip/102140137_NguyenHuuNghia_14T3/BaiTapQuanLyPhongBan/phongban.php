<?php 
    require_once 'templates/header.php';

    if (!isset($_SESSION['user'])) {
        header("location: login.php");
    }
?>
<!-- Breadcrumbs-->
    <!-- Example DataTables Card-->
    <div class="card mb-3">
        <div class="card-header">
            <i class="fa fa-table"></i> PHÒNG BAN</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Mã phòng ban</th>
                            <th>Mô tả</th>
                            <th>Thời gian</th>
                            <th>Xem nhân viên</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $query = "select * from phongban";
                        $result = $connect->query($query);
                        $i = 0;

                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['id'];
                            $mota = $row['mota'];
                            $mapb = $row['mapb'];
                            $thoigian = $row['thoigian'];
                    ?>
                        <tr>
                            <td><?php echo ++ $i ?></td>
                            <td><?php echo $mapb ?></td>
                            <td><?php echo $mota ?></td>
                            <td><?php echo $thoigian ?></td>
                            <td>
                                <a class="btn btn-primary" href="nhanvien.php?id=<?php echo $id ?>">Nhân viên</a>
                            </td>
                        </tr>
                    <?php 
                        }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php 
    require_once 'templates/footer.php';
?>
