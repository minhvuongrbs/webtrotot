$(document).ready(function() {
	$('.delete-nv').on('click', function(event) {
		event.preventDefault();
		var id = $(this).attr('id');

		$.ajax({
			url: 'delete.php',
			type: 'POST',
			data: {
				id: id,
			},
			success: function(data) {
				window.location.reload();
				alert(data);
			},
		});
		
	});
});
