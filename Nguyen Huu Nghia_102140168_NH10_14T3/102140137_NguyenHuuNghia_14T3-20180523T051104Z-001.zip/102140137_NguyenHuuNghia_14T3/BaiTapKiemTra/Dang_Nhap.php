<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Đăng nhập</title>
	<script type="text/javascript" src="vendor/bootstrap.js"></script>
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="vendor/bootstrap.css">
	<link rel="stylesheet" href="vendor/font-awesome.css">
 	<link rel="stylesheet" href="baitap.css">
</head>
<body>

	<?php
	    $ketnoi = mysql_connect("localhost","root","");
	    if(!$ketnoi)
	        echo "Kết nối thất bại";
	 
	    mysql_select_db("dbuser",$ketnoi);
        //echo 'thành công';
	 
	    mysql_query("set names utf8");   //hiển thị tiếng việt, không có sẽ bị lỗi font chữ

	    //kích hoạt session: lưu tạm thời, khi thoát trình duyệt mở lại sẽ ko đc, còn cookie thì được.
	    session_start();
	?>
	<br>
	<div class="container">
		<div class="row">
			<div class="col-sm-8 push-sm-2">
				<div class="card">
					<div class="card-block">
						<div class="modal-header" style="padding:45px 50px;">
						<h3 class="text-xs-center"><span class="glyphicon glyphicon-lock"></span> Đăng nhập </h3>
						</div>
						<br>
						<div id="thongbao1" style="color: red; font-size: 15px;" class="hide">
                 		</div>
						<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" accept-charset="utf-8">
							<fieldset class="form-group">
								<label for="formGroupExampleInput"><span class="glyphicon glyphicon-user"></span> Tên đăng nhập</label>
								<input type="text" class="form-control" id="formGroupExampleInput" name="tendangnhap" placeholder="Tên tài khoản" >
							</fieldset>
							<fieldset class="form-group">
								<label for="formGroupExampleInput2"><span class="glyphicon glyphicon-eye-open"></span> Mật khẩu</label>
								<input type="password" class="form-control" id="formGroupExampleInput2" name="matkhau" placeholder="Mật khẩu" >
							</fieldset>
							<fieldset>
								<a  class="dangky hide" href='Dang_Ky.php'>Đăng ký </a>
								<button type="submit" class="btn btn-primary" style="margin-left: 23px" value="">Đăng nhập 
									<span class="glyphicon glyphicon-log-in"></span>
								</button>
							</fieldset>
						</form>
					</div>
				</div>
			</div>		
		</div>
	</div>

	<?php 
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
 
			$tendangnhap = $_POST['tendangnhap'];
			$matkhau = $_POST['matkhau'];

			$kiemtra_taikhoan = "SELECT * from user where ten_dang_nhap ='".$tendangnhap."' and mat_khau ='".$matkhau."'";
			$truyvan_kiemtra = mysql_query($kiemtra_taikhoan);
			if(mysql_num_rows($truyvan_kiemtra))
			{
				header("location:Quan_Ly.php");
				$_SESSION['tendangnhap'] = $tendangnhap;
			}
			else
			{
				//echo 'Tên đăng nhập hoặc mật khẩu không đúng';
				echo "<script>$('#thongbao1').text('Tài khoản hoặc mật khẩu không đúng, xin vui lòng thử lại!');</script>";
            	echo "<script>$('.alert-danger').removeClass('hide')</script>";  
            	echo "<script>$('.dangky').removeClass('hide')</script>";  
			}
		}
	?>

</body>
</html>