-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 04 Mai 2018 à 05:58
-- Version du serveur :  5.6.21
-- Version de PHP :  5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `dbuser`
--

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `ten_dang_nhap` text NOT NULL,
  `mat_khau` text NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `full_name` text NOT NULL,
  `dia_chi` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `ten_dang_nhap`, `mat_khau`, `first_name`, `last_name`, `full_name`, `dia_chi`, `role`) VALUES
(1, 'huunghia88', '123123', 'Nghia', 'Nguyen', 'Nghia Nguyen', 'Huế', 0),
(2, 'hoaiphuc', '123123', 'phuc', 'hoai', 'phuc hoai', 'Đà Nẵng', 1),
(4, 'user02', '123123', 'Trường', 'Phạm', 'Phạm Trường', 'Việt Nam', 1),
(5, 'user03', '123123', 'Công Phượng', 'Nguyễn', 'Nguyễn Công Phượng', 'Nghệ An', 1),
(6, 'user04', '123123', 'Văn Toàn', 'Nguyễn', 'Nguyễn Văn Toàn', 'Hải Dương', 1),
(7, 'user', '123123', 'Phi Sơn', 'Trần', 'Trần Phi Sơn', 'Nghệ An', 1),
(8, 'admin', 'admin', 'admin', 'admin', '', 'bí mật', 0),
(9, 'abcd', '123123', 'test1', 'test1', 'test1', 'aa', 1),
(10, 'abcdef', '123123', 'nghia', 'kute', 'Trần Đại Nghĩa', 'Việt Nam', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
