<?php
	$ketnoi = mysql_connect('localhost','root','');
	if(!$ketnoi)
		echo 'Kết nối thất bại';

	mysql_select_db('dbuser', $ketnoi);

	mysql_query('set names utf8');

	session_start();

	$lay_role = "select role from user where ten_dang_nhap = '".$_SESSION['tendangnhap']."'";
    	$truy_van = mysql_query($lay_role);
    	$cot_role = mysql_fetch_array($truy_van);

	$query = $_POST["query"];

	$lay_user = "SELECT * FROM user WHERE first_name like '%".$query."%'";
	$truyvan_layuser = mysql_query($lay_user);

?>
<table class="table table-striped list" id="list_nhanvien">
		<th>Mã ID</th><th>Tên đăng nhập</th><th>FirstName</th><th>LastName</th><th>FullName</th><th>Địa chỉ</th>
		<?php /*if($_SESSION['tendangnhap'] == "admin") {*/
			  if($cot_role["role"] == '0') {
		?>
		<th>Chức năng</th>
		<?php }else{ ?>
		
		<?php 
		}
			while($cot = mysql_fetch_array($truyvan_layuser))
			{
				echo "<tr>";
				
		        echo "  <td>".$cot["id"]."</td>
		        		<td>".$cot["ten_dang_nhap"]."</td>
		        		<td>".$cot["first_name"]."</td>
		        		<td>".$cot["last_name"]."</td>
		        		<td>".$cot["full_name"]."</td>
		        		<td>".$cot["dia_chi"]."</td>
		            ";
		        if($cot_role["role"] == "0")
		        {
			        echo "
			        	<td><a href='Chinh_Sua.php?MaID=".$cot["id"]."' class='btn btn-primary btn-sm'>Chỉnh sửa </a>
			        	&nbsp;
			        	<a class='btn btn-danger xoa btn-sm' href='Quan_Ly.php?MaUser=".$cot["id"]."' data-id=".$cot["id"]."> Xóa </a>
			        	</td>";
			    }
		        echo "</tr>";
			}

		?>
	</table>