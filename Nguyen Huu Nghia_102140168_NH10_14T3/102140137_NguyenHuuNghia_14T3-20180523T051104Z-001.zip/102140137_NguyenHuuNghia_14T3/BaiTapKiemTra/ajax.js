function timkiem_user(searchQuery){
	$.ajax({
		url:"TK_ajax.php",
		type:"POST",
		data:{
			query:searchQuery
		},
		success:function(ketqua){
			$("#ketqua").html(ketqua);
		}
	});
}

