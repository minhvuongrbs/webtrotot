<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>QUẢN LÝ THÔNG TIN USER</title>

<script type="text/javascript" src="vendor/bootstrap.js"></script>
<script type="text/javascript" src="vendor/bootstrap.min.js"></script>    
<script type="text/javascript" src="vendor/jquery-1.11.1.min.js"></script>    
<script type="text/javascript" src="vendor/jquery.min.js"></script>

<!-- <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->

<link rel="stylesheet" type="text/css" href="vendor/bootstrap.min.css">
<link rel="stylesheet" href="vendor/bootstrap.css">
<link rel="stylesheet" href="vendor/font-awesome.css">
<link rel="stylesheet" href="baitap.css">

<?php 
    $ketnoi = mysql_connect("localhost","root","");
    if(!$ketnoi)
        echo "Ket noi that bai";
 
    mysql_select_db("dbuser",$ketnoi);
    //echo 'thành công';
 
    mysql_query("set names utf8");

    session_start();
?>
</head>
<body>
	<?php
		if(isset($_COOKIE['tendangnhap']))
		{
			$_SESSION['tendangnhap'] = $_COOKIE['tendangnhap'];
		}

		if(!isset($_SESSION['tendangnhap']))
		{
			header('location:Dang_Nhap.php');
		}
			
		if(isset($_GET["MaUser"]))
    	{
    		if($_GET["MaUser"] != "1")
    		{
    			$xoa_taikhoan="DELETE FROM user where id='".$_GET["MaUser"]."'";
	        if(mysql_query($xoa_taikhoan))
	            echo "Xoa thanh cong";
	        else
	            echo "Khong the xoa";
    		}
	        
    	}

    	$lay_role = "select role from user where ten_dang_nhap = '".$_SESSION['tendangnhap']."'";
    	$truy_van_lay_role = mysql_query($lay_role);
    	$cot_role = mysql_fetch_array($truy_van_lay_role);
	?>

	<?php 
		if(isset($_GET['DangXuat']))
		{
			unset($_SESSION['tendangnhap']);
			setcookie('tendangnhap',$tendangnhap,time());
			header('location:Dang_Nhap.php');
		}
	?>
	<div class="container mt-2">
	<h2>Quản lý thông tin User</h2>
	<form method="post" action="#" class="form">
		<div class="col-xs-7">
			<div class="input-group">
				<input type="text" name="searchQuery" id="searchQuery" value="" class="form-control">	
			</div>
		</div>
		<span class="input-group-btn"> 
	        <input type="button" value="Tìm kiếm" id="timkiem" class="btn btn-info">
		</span>
	</form>
	<div class="alert alert-danger hide">
 
    </div>
    <div class="alert alert-success hide">

    </div>

	<h6 style="margin-left: 900px;">
		Tài khoản <?php echo $_SESSION['tendangnhap']; ?>
		<div>
			<a href="Quan_Ly.php?DangXuat=1">&nbsp;Đăng xuất</a>
		</div>
	</h6>

	<div id="ketqua">
	<table class="table table-striped list" id="list_nhanvien">
		<th>Mã ID</th><th>Tên đăng nhập</th><th>FirstName</th><th>LastName</th><th>FullName</th><th>Địa chỉ</th>
		<?php /*if($_SESSION['tendangnhap'] == "admin") {*/
			  if($cot_role["role"] == '0') {
		?>
		<th>Chức năng</th>
		<?php }else{ ?>
		
		<?php 
		}
			$lay_toanbo_user="SELECT * FROM user ";
			$truyvan_lay_toan_bo_user=mysql_query($lay_toanbo_user);
			while($cot = mysql_fetch_array($truyvan_lay_toan_bo_user))
			{
				echo "<tr>";
				
		        echo "<td>".$cot["id"]."</td>
		        		<td>".$cot["ten_dang_nhap"]."</td>
		        		<td>".$cot["first_name"]."</td>
		        		<td>".$cot["last_name"]."</td>
		        		<td>".$cot["full_name"]."</td>
		        		<td>".$cot["dia_chi"]."</td>
		            ";

		        if($cot_role["role"] == "0")
		        {
			        
			        echo "
			        	<td><a href='Chinh_Sua.php?MaUser=".$cot["id"]."' class='btn btn-primary btn-sm'>Chỉnh sửa </a>
			        	&nbsp;
			        	<a class='btn btn-danger xoa btn-sm' href='Quan_Ly.php?MaUser=".$cot["id"]."' data-id=".$cot["id"]."> Xóa </a></td>";
			    }
		        echo "</tr>";
			}

		?>
	</table>
	</div>
	</div>
	<div class="container">
		<div class="panel panel-success">
			<div class="panel-body">
				<?php if($cot_role["role"] == "0"){ ?>
					<a href="Dang_Ky.php" class="btn btn-primary">Thêm user</a>
				<?php }else{ ?>
					
				<?php } ?>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="baitap.js"></script>
	<script type="text/javascript" src="ajax.js"></script>
<script>
    $(document).ready(function(){
        $("#timkiem").click(function(){
        timkiem_user($("#searchQuery").val());
        
        });
    });
</script>
</body>
</html>