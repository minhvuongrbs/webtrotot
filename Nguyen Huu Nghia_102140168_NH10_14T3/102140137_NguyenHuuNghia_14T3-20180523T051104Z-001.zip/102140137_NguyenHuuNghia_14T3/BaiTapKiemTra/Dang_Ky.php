<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Đăng ký</title>
    <script type="text/javascript" src="vendor/bootstrap.js"></script>
    <script type="text/javascript" src="vendor/bootstrap.min.js"></script>    
    <script type="text/javascript" src="vendor/jquery-1.11.1.min.js"></script>    
<script type="text/javascript" src="vendor/jquery.min.js"></script>

<!-- <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->

<link rel="stylesheet" type="text/css" href="vendor/bootstrap.min.css">
<link rel="stylesheet" href="vendor/bootstrap.css">
<link rel="stylesheet" href="vendor/font-awesome.css">
<link rel="stylesheet" href="baitap1.css">
    <?php
        $ketnoi = mysql_connect("localhost","root","");
        if(!$ketnoi)
            echo "Kết nối thất bại";
     
        mysql_select_db("dbuser",$ketnoi);
        //echo 'thành công';
     
        mysql_query("set names utf8");   //hiển thị tiếng việt, không có sẽ bị lỗi font chữ

        //kích hoạt session: lưu tạm thời, khi thoát trình duyệt mở lại sẽ ko đc, còn cookie thì được.
        session_start();
    ?>
</head>
<body>
 <div class="container">
        <div class="row">
            <div class="col-sm-8 push-sm-2">
                <div class="card">
                    <div class="card-block">
                        <h3 class="text-xs-center">Đăng ký</h3>
                        <div id="thongbao" style="color: red; font-size: 15px;">        
                        </div>
                        <br>
                        <form method="post" action="<?php echo $_SERVER["PHP_SELF"] ?>">
                            <fieldset class="form-group">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 form-control-label">Tên đăng nhập</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="tendangnhap" name="tendangnhap" placeholder="">
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="form-group">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 form-control-label">Mật khẩu</label>
                                    <div class="col-sm-9">
                                        <input type="password" class="form-control" name="matkhau" id="matkhau" placeholder="">
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="form-group">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 form-control-label">FirstName</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="">
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="form-group">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 form-control-label">LastName</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="">
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="form-group">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 form-control-label">FullName</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="fullname" name="fullname" placeholder="">
                                    </div>
                                </div>
                            </fieldset>
                            
                            <fieldset class="form-group">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-3 form-control-label">Địa chỉ</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="diachi" name="diachi" placeholder="">
                                    </div>
                                </div>
                            </fieldset>
                            
                            <fieldset class="form-group">
                                <input type="submit" class="btn btn-primary ml-auto" id="themmoi" value="Thêm mới">
                            </fieldset>
                             <fieldset class="form-group">
                                <a href="Quan_Ly.php">Quay lại trang chủ</a>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php 
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        $tendangnhap=$_POST["tendangnhap"];
        $matkhau=$_POST["matkhau"];
        $firstname=$_POST["firstname"];  
        $lastname=$_POST["lastname"];
        $fullname=$_POST["fullname"];   
        $diachi=$_POST["diachi"];
        $role = 1;
     
        
        $ktTonTai = "SELECT * FROM user WHERE ten_dang_nhap = '" . $tendangnhap . "'";
        $truyVanktTonTai = mysql_query($ktTonTai);
        if (mysql_num_rows($truyVanktTonTai) > 0)
            echo "<script>$('#thongbao').text('Tài khoản đã tồn tại');</script>";
        else {
            $themUser="INSERT INTO user VALUES('','".$tendangnhap."','".$matkhau."','".$firstname."','".$lastname."','".$fullname."','".$diachi."', '".$role."')";

            $truyVanthemUser=mysql_query($themUser);
            if($truyVanthemUser)
            {
                echo "<script>$('#thongbao').text('Thêm user thành công');</script>";
                echo "<script>alert('Thêm user thành công');</script>";
                echo "<script>
                    location='Quan_Ly.php';
                    </script>";
            }
        }
    
    }
?>
<script>
    $(document).ready(function(){
        $('#themmoi').click(function(){
            tendangnhap=$('#tendangnhap').val();
            matkhau=$('#matkhau').val();
            //nhaplaimatkhau=$('#nhaplaimatkhau').val();
            firstname=$('#firstname').val();
            lastname=$('#lastname').val();
            fullname=$('#fullname').val();
            diachi=$('#diachi').val();
 
            loi=0;
            if(tendangnhap=="" || matkhau=="" || firstname=="" || lastname=="" || fullname=="" || diachi=="")
            {
                loi++;
                $('#thongbao').text("\"Hãy nhập đầy đủ thông tin\"");
            }
 
            if(loi!=0)
            {
                return false;
            }
        });
    });
</script>

</body>
</html>

