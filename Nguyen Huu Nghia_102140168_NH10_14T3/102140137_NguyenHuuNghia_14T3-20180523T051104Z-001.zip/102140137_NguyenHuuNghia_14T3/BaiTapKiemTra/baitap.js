﻿
$(document).ready(function(){
    $('.list input[type="checkbox"]:eq(0)').change(function() {
        $('.list input[type="checkbox"]').prop('checked', $(this).prop("checked"));
    });

    $('#del_nhanvien_list').click(function(){
        $confirm = confirm('Bạn có chắc chắn muốn xóa các nhân viên đã chọn không?');
        if($confirm == true)
        {
            $id_nhanvien = [];

            $('#list_nhanvien input[type="checkbox"]:checkbox:checked').each(function(i){
                $id_nhanvien[i] = $(this).val(); 
            });

            //console.log($id_nhanvien);

            if($id_nhanvien.length === 0)
            {
                alert('Vui lòng chọn ít nhất một nhân viên.');
            }
            else
            {
                $.ajax({
                    url:'Quan_Ly.php',
                    type: 'POST',
                    data: {
                        id_nhanvien : $id_nhanvien,
                        action : 'delete_nhanvien_list'
                    },
                    success : function(data){
                        //location.reload();
                        $('.alert-success').html('Xóa thành công').removeClass('hide');
                        $('.alert-danger').addClass('hide');
                        alert('Thành công');
                        // setTimeout(function(){
                        //     // Ẩn thông báo lỗi
                        //     $('.alert-danger').addClass('hide');
                        //     $('.alert-success').addClass('hide');
                        // }, 3000);
                    },
                    error : function(data){
                        alert('Đã có lỗi xảy ra, hãy thử lại.');
                        $('.alert-danger').html('Đã có lỗi xảy ra, hãy thử lại.').removeClass('hide');
                        $('.alert-success').addClass('hide');
                    }
                });
            }
        }
        else
            return false;
    });

    $(".del-nhanvien-list").click(function(){
        $confirm = confirm('Bạn có chắc chắn muốn xoá nhân viên này không?');
        if ($confirm == true)
        {
            $id_nhanvien = $(this).attr('data-id'); //lấy giá trị của thuộc tính .attr('tên thuộc tính')

            $.ajax({
                url : 'Quan_Ly.php',
                type : 'POST',
                data : {
                    id_nhanvien : $id_nhanvien,
                    action : 'delete_nhanvien'
                },
                success : function(data){
                    location.reload();
                },
                error : function(data){

                }

            });
        }
        else
            return false;  
    });
});